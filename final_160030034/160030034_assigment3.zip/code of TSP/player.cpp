#include "player.h"

void player::set_goods(int num){
    goods = num;
}

void player::set_state(state *n){
     s = n;
}


int player::get_goods(){
    return goods;
}

state* player::get_state(){
    return s;
}

void player::sell_goods(int num_of_buys){
    goods -= num_of_buys;
    if(goods<0){
        goods = 0;
    }
}

int player::get_category(int tot_goods, int tot_cats){
    return int((double(goods)/tot_goods)*double(tot_cats));
}