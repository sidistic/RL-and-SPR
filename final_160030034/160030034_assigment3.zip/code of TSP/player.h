#include "state.h"

class player{
    int goods;
    state *s;

    public:

    void set_goods(int num);
    void set_state(state *n);

    int get_goods();
    state* get_state();

    void sell_goods(int num_of_buys);

    int get_category(int tot_goods, int tot_cats);
};