#include <iostream>
#include "city.h"
#include <iterator>
#include "player.h"
#include <random>

using namespace std;

void initialize_city_characteristics3(map<char, city*> c);
void initialize_city_characteristics5(map<char, city*> c);
void initialize_city_characteristics10(map<char, city*> c);

char get_next_action_based_on_Q(state* S,map<state*, double*> Q, double epsilon, int num_of_cities);

int main(){

    map<char, city*> cities = parse_adj_matrix_file("test_city_n3.txt");

    // These values must be changed every time the file is changed
    initialize_city_characteristics3(cities);
    int total_goods=340;
    int number_of_cities=3;
    int number_of_categories=10;
    state*** states = new state**[number_of_cities];
    for(int i=0;i<number_of_cities;i++) states[i] = new state*[number_of_categories];

    double alpha = 0.5;
    double epsilon = 0.3;
    double gamma = 1;

    // initialising Q
    map<state*, double*> Q;
    for(int i=0;i<number_of_cities;i++){
        for(int j=0;j<number_of_categories;j++){
            state* temp = new state(j,'A'+i);
            states[i][j] = temp;
            Q.insert({temp,new double[number_of_cities]});
            for(int k=0;k<number_of_cities;k++){
                Q.find(temp)->second[k] = 0;
            }
        }
    }

    // Sarsa
    int num_of_episodes = 1000;

    for(int i=0;i<num_of_episodes;i++){
        // cout<<"ep:"<<i<<endl;
        initialize_city_characteristics3(cities);
        player pl;
        pl.set_goods(total_goods);
        // cout<<"m"<<endl;
        state* S = states['A'-65][number_of_categories-1];
        // cout<<"m"<<endl;
        pl.set_state(S);
        // cout<<"m"<<endl;
        // cout<<"m"<<endl;
        while(pl.get_goods()!=0){
            // cout<<"n"<<endl;
            
            char A = get_next_action_based_on_Q(S,Q,epsilon, number_of_cities);
            // cout<<A<<" "<<pl.get_goods()<<" !";
            int buys = cities.find(A)->second->get_buys();
            // cout<<buys<<"! #";
            int move_cost = cities.find(pl.get_state()->get_city())->second->get_dist_to_city(A);
            pl.sell_goods(buys);
            // cout<<pl.get_goods()<<"# ";
            pl.set_state(states[A-65][pl.get_category(total_goods,number_of_categories)]);
            double R = double(buys)*2 - double(move_cost)*3;

            char A1 = get_next_action_based_on_Q(pl.get_state(),Q, 0, number_of_cities);
            Q.find(S)->second[A-65] = Q.find(S)->second[A-65] + alpha*(R + gamma*(Q.find(pl.get_state())->second[A1-65]) - Q.find(S)->second[A-65]);
            S = pl.get_state();
        }
    }
    cout<<"\t";
    for(int j=0;j<number_of_categories;j++){
        cout<<j<<"\t";
    }
    cout<<endl;
    for(int i=0;i<number_of_cities;i++){
        cout<<char(65+i)<<":\t";
        for(int j=0;j<number_of_categories;j++){
            cout<<get_next_action_based_on_Q(states[i][j],Q,0,number_of_cities)<<"\t";
        }
        cout<<endl;
    }
}

char get_next_action_based_on_Q(state* S,map<state*, double*> Q, double epsilon, int num_of_cities){
    static default_random_engine generator;
    uniform_real_distribution<double> distribution(0.0,1.0);
    double prob = distribution(generator);
    if(prob < epsilon){
        uniform_int_distribution<int> rand_cities(0, num_of_cities-1);
        return char(65 + rand_cities(generator));
    }
    int max_index = 0;
    double max_val = Q.find(S)->second[0];
    for(int i =1;i<num_of_cities;i++){
        if(max_val < Q.find(S)->second[i]){
            max_val = Q.find(S)->second[i];
            max_index = i;
        }
    }
    return char('A' + max_index);
}

void initialize_city_characteristics3(map<char, city*> c){
    c.find('A')->second->set_num_of_customers(40);
    c.find('A')->second->set_prob(0.8);
    c.find('A')->second->find_possible_rewards();

    c.find('B')->second->set_num_of_customers(200);
    c.find('B')->second->set_prob(0.3);
    c.find('B')->second->find_possible_rewards();

    c.find('C')->second->set_num_of_customers(100);
    c.find('C')->second->set_prob(0.6);
    c.find('C')->second->find_possible_rewards();
}
void initialize_city_characteristics5(map<char, city*> c){
    c.find('A')->second->set_num_of_customers(50);
    c.find('A')->second->set_prob(0.8);
    c.find('A')->second->find_possible_rewards();

    c.find('B')->second->set_num_of_customers(200);
    c.find('B')->second->set_prob(0.3);
    c.find('B')->second->find_possible_rewards();

    c.find('C')->second->set_num_of_customers(100);
    c.find('C')->second->set_prob(0.6);
    c.find('C')->second->find_possible_rewards();

    c.find('D')->second->set_num_of_customers(80);
    c.find('D')->second->set_prob(0.1);
    c.find('D')->second->find_possible_rewards();

    c.find('E')->second->set_num_of_customers(300);
    c.find('E')->second->set_prob(0.4);
    c.find('E')->second->find_possible_rewards();

}
void initialize_city_characteristics10(map<char, city*> c){
    c.find('A')->second->set_num_of_customers(50);
    c.find('A')->second->set_prob(0.8);
    c.find('A')->second->find_possible_rewards();

    c.find('B')->second->set_num_of_customers(200);
    c.find('B')->second->set_prob(0.3);
    c.find('B')->second->find_possible_rewards();

    c.find('C')->second->set_num_of_customers(100);
    c.find('C')->second->set_prob(0.6);
    c.find('C')->second->find_possible_rewards();

    c.find('D')->second->set_num_of_customers(80);
    c.find('D')->second->set_prob(0.1);
    c.find('D')->second->find_possible_rewards();

    c.find('E')->second->set_num_of_customers(300);
    c.find('E')->second->set_prob(0.4);
    c.find('E')->second->find_possible_rewards();

    c.find('F')->second->set_num_of_customers(120);
    c.find('F')->second->set_prob(0.9);
    c.find('F')->second->find_possible_rewards();

    c.find('G')->second->set_num_of_customers(20);
    c.find('G')->second->set_prob(1);
    c.find('G')->second->find_possible_rewards();

    c.find('H')->second->set_num_of_customers(500);
    c.find('H')->second->set_prob(0.35);
    c.find('H')->second->find_possible_rewards();

    c.find('I')->second->set_num_of_customers(250);
    c.find('I')->second->set_prob(0.5);
    c.find('I')->second->find_possible_rewards();

    c.find('J')->second->set_num_of_customers(400);
    c.find('J')->second->set_prob(0.45);
    c.find('J')->second->find_possible_rewards();

}