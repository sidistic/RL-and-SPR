import numpy as np
import gym
import matplotlib.pyplot as plt
import time

#initialise Mountain Car Environment
env = gym.make('MountainCar-v0')
env.reset()
    # return env

def discretize(state, env):
    state_discretized = (state - env.observation_space.low)*np.array([10, 100])
    state_discretized = np.round(state_discretized, 0).astype(int)
    return state_discretized

def choose_act(Q, state, epsilon):
    pr = np.random.uniform(low=0.0, high=1.0)
    if pr > epsilon:
        action = np.argmax(Q[state[0], state[1]]) 
    else:
        action = np.random.randint(0, 3)
    return action

def q_learning(num_of_episodes):
    alpha = 0.2
    epsilon = 0.5
    gamma = 1.0
    global env

    num_states = (env.observation_space.high - env.observation_space.low)*np.array([10, 100])
    num_states = np.round(num_states, 0).astype(int) + 1
    
    #init Q
    Q = np.random.uniform(low = -1, high = 1,size = (19, 15, 3))

    total_rewards= []

    #reduction
    rd = (epsilon)/num_of_episodes

    for i in range(0,num_of_episodes):
        done = False
        tot_rw =0
        reward=0
        state = env.reset()
        state_discretized = discretize(state,env)

        while(done == False):
            # Render environment for last five episodes
            if i >= (num_of_episodes - 5):
                env.render()
            
            a = choose_act(Q,state_discretized,epsilon)
            #make move and get next state
            new_state, reward, done, info = env.step(a)
            new_state_discretized = discretize(new_state,env)
            if done and new_state[0] >= 0.5:
                Q[state_discretized[0], state_discretized[1], a] = reward
            else:
                Q[state_discretized[0], state_discretized[1],a] += alpha*(reward + gamma*np.max(Q[new_state_discretized[0], new_state_discretized[1]]) - Q[state_discretized[0], state_discretized[1],a])
            
            tot_rw += reward
            state_discretized = new_state_discretized
        # reducing epsilon
        if epsilon > 0:
            epsilon -= rd
        
        total_rewards.append(tot_rw)

    env.close()

    return total_rewards

def sarsa(num_of_episodes):
    alpha = 0.2
    epsilon = 0.5
    gamma = 1.0
    global env

    num_states = (env.observation_space.high - env.observation_space.low)*\
        np.array([10, 100])
    num_states = np.round(num_states, 0).astype(int) + 1
    
    #init Q
    Q = np.random.uniform(low = -1, high = 1,size = (19, 15, 3))

    total_rewards= []

    #reduction
    rd = (epsilon)/num_of_episodes

    for i in range(0,num_of_episodes):
        done = False
        tot_rw =0
        reward=0
        state = env.reset()
        state_discretized = discretize(state,env)
        a = choose_act(Q,state_discretized,epsilon)
        

        while(done == False):
            # Render environment for last five episodes
            if i >= (num_of_episodes - 5):
                env.render()
            
            #make move and get next state
            new_state, reward, done, info = env.step(a)
            new_state_discretized = discretize(new_state,env)
            a1 = choose_act(Q, new_state_discretized, epsilon)

            #terminal state check
            if done and new_state[0] >= 0.5:
                Q[state_discretized[0], state_discretized[1], a] = reward
            else:
                Q[state_discretized[0], state_discretized[1],a] += alpha*(reward + gamma*np.max(Q[new_state_discretized[0], new_state_discretized[1]]) - Q[state_discretized[0], state_discretized[1],a])
            
            tot_rw += reward
            state_discretized = new_state_discretized
            a = a1
        # reducing epsilon
        if epsilon > 0:
            epsilon -= rd
        
        total_rewards.append(tot_rw)
        # if(i%50==0):
        #     print(i,":",tot_rw)

    env.close()

    return total_rewards

def generate_episode(env,Q,epsilon):

    S = env.reset()
    S_discretized = discretize(S,env)
    A = choose_act(Q, S_discretized,epsilon)
    t = []

    while(True):
        S1, R, done, info = env.step(A)
        S1_discretized = discretize(S1,env)
        A1 = choose_act(Q, S1_discretized,epsilon)
        tn = [S,A,R]
        # print(tn)
        t.append(tn)

        if(S1_discretized[0] >= 5.0 and done == True):
            break
        else:
            S = S1
            A = A1
        
    return t

def monte_carlo(num_of_episodes):

    epsilon = 0.5
    global env
    Q = np.random.uniform(low = -1, high = 1, size = (19, 15, 3))
    number_visited = np.zeros([19, 15, 3], dtype=int)
    rd = epsilon/num_of_episodes
    total_rewards= []
    for i in range(0,num_of_episodes):
        print(i)
        if i >= (num_of_episodes - 5):
                env.render()
        G = 0
        start_st = env.reset()
        T = generate_episode(env,Q,epsilon)
        # print(i)
        if epsilon > 0:
            epsilon -= rd
        for i in range(len(T)-1,-1,-1):
            step = T[i]
            R = step[2]
            G+=R
            st = step[0]
            st_discretized = discretize(st,env)
            at = step[1]
            number_visited[st_discretized[0],st_discretized[1],at] += 1.0
            Q[st_discretized[0],st_discretized[1],at]= Q[st_discretized[0],st_discretized[1],at] + (1/(number_visited[st_discretized[0],st_discretized[1],at]+1))*(G-Q[st_discretized[0],st_discretized[1],at])
        
        total_rewards.append(G)
    
    return total_rewards

def get_avg(list):
    avg = []
    for i in range(0,len(list)-10):
        avg.append(np.mean(list[i:i+10]))
    return avg

start_time = time.time()
res_mc = monte_carlo(5000)
print("MC finished in %s seconds" % (time.time()-start_time))
start_time = time.time()
res_sarsa = sarsa(5000)
print("SARSA finished in %s seconds" % (time.time()-start_time))
start_time = time.time()
res_ql = q_learning(5000)
print("Q-Learning finished in %s seconds" % (time.time()-start_time))
plt.plot(get_avg(res_mc), label = "Monte-Carlo")
plt.plot(get_avg(res_sarsa), label = "SARSA")
plt.plot(get_avg(res_ql), label = "Q-Learning")
plt.xlabel('Episodes')
plt.ylabel('Total Reward')
plt.title('Total Reward vs Episodes')
plt.legend()
plt.show()
        