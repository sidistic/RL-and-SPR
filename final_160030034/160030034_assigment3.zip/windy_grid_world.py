import enum
import sys
import numpy as np
import matplotlib.pyplot as plt
import random
import time

# grid world is a 2D int array with the values being the reward at that
# state and state being the row and column indexes.
grid_world = [
    [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1],
    [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1],
    [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1],
    [-1,-1,-1,-1,-1,-1,-1, 0,-1,-1],
    [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1],
    [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1],
    [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]]

# wind is an array which holds the number of grids the player would
# at the column(y index)
wind = [0, 0, 0, 1, 1, 1, 2, 2, 1, 0]

# actions is a set of all possible actions possible actions enumerated
up      = 0
down    = 1
left    = 2
right   = 3

m = 0

# state is row and column pair. if x is the row then
# x+1th row from the top of the grid. similarly y from left to right.
start_state = [3,0]
goal_state = [3,7]

grid_world[goal_state[0]][goal_state[1]] = 0;

class player():
    state_x = 0
    state_y = 0

    def __init__(self, nx,ny):
        self.state_x=nx
        self.state_y=ny
    
    # take_action makes the move in the grid and returns the reward
    # for the move
    def take_action(self,a):
        self.state_x -= wind[self.state_y]
        if self.state_x < 0 :
            self.state_x = 0
        if a == left and self.state_y !=0 :
            # print("L")
            self.state_y -= 1
        elif a == right and self.state_y !=9:
            # print("R",self.state_y)
            self.state_y += 1
        elif a == up and self.state_x !=0:
            # print("U")
            self.state_x -= 1
        elif a == down and self.state_x !=6:
            # print("D")
            self.state_x += 1
        
        return grid_world[self.state_x][self.state_y]

def state_to_int(state):
    return state[0]*len(grid_world[0]) + state[1]

# return a map of [state_x, state_y][action] to value
def init_Q():
    Q=[]
    for i in range(0,len(grid_world)):
        for j in range(0,len(grid_world[i])):
                Q.append([0,0,0,0])
    return Q

# returns a map from state to action, i.e this initializes
# a policy. pi[state_x,state_y] = [a*, epsilon]
def init_pi(epsilon):
    pi=[]
    for i in range(0,len(grid_world)):
        for j in range(0,len(grid_world[i])):
            if(j>8):
                pi.append([down, epsilon])
            else:
                pi.append([right, epsilon])
    return pi

def init_returns():
    ret =[]
    for i in range(0,len(grid_world)):
        for j in range(0,len(grid_world[i])):
            ret.append([[], [], [], []])
    return ret

def get_next_action(state_x,state_y,policy,Q):
    pr = np.random.uniform(low=0.0, high=1.0)
    e = policy[state_to_int([state_x,state_y])][1]
    act = right # random, just to initialize
    if e > pr:
        act = np.random.randint(low=0,high=4)
    else:
        act = policy[state_to_int([state_x,state_y])][0]
    return act

def get_next_action_based_on_Q(state_x,state_y,Q,epsilon):
    global m
    pr = np.random.uniform(low=0.0, high=1.0)
    act = right # random, just to initialize
    if epsilon > pr:
        act = np.random.randint(low=0,high=4)
    else:
        act = np.argmax(Q[state_to_int([state_x,state_y])])
    return act

# p = player. return list of <[state],action,reward> tuples
def generate_episode(p,policy,Q):
    t = []
    i=0
    while(p.state_x!=goal_state[0] or p.state_y!=goal_state[1]):
        tn = [[p.state_x,p.state_y]]
        an = get_next_action(p.state_x,p.state_y,policy,Q)
        tn.append(an)
        rt_1 = p.take_action(an)
        # if (i<20):
        # print(tn[0],an,[p.state_x,p.state_y])
        # i+=1
        tn.append(rt_1)
       
        t.append(tn)
    return t

def monte_carlo(num_of_episodes):
    gamma = 0.8
    epsilon = 0.5
    
    # Initialization
    pi = init_pi(epsilon)
    Q = init_Q()
    returns = init_returns()
    total_returns =[]
    

    #MC
    for i in range(0, num_of_episodes):
        pl = player(np.random.randint(low=0, high=7),np.random.randint(low=0, high=10))
        episode = generate_episode(pl,pi,Q)
        print(i)
        G = 0
        s=0
        for j in range(len(episode)-1,-1,-1):
            step = episode[j]
            st = step[0]
            at = step[1]
            rt_1 = step[2]
            G = gamma*G + rt_1
            s+=rt_1
            returns[state_to_int(st)][at].append(G)
            Q[state_to_int(st)][at] = np.average(returns[state_to_int(st)][at])
            a_star = np.argmax(Q[state_to_int(st)])
            pi[state_to_int(st)][0] = a_star
            # pi[state_to_int(st)][1] = pi[state_to_int(st)][1]/4
        total_returns.append(s)
    return [Q,total_returns]

def sarsa(num_of_episodes):
    alpha = 0.5
    epsilon = 0.3
    gamma = 0.8
    Q = init_Q()
    total_returns = []
    for i in range(0, num_of_episodes):
        # print(i)
        pl = player(start_state[0],start_state[1])
        S = [pl.state_x,pl.state_y]
        A = get_next_action_based_on_Q(pl.state_x,pl.state_y,Q,epsilon)
        tot_rw= 0
        while(pl.state_x!=goal_state[0] or pl.state_y!=goal_state[1]):
            R = pl.take_action(A)
            tot_rw+=R
            A1 = get_next_action_based_on_Q(pl.state_x,pl.state_y,Q,epsilon)
            Q[state_to_int(S)][A] = Q[state_to_int(S)][A] + alpha*(R + gamma*(Q[state_to_int([pl.state_x,pl.state_y])][A1]) - Q[state_to_int(S)][A])
            S = [pl.state_x,pl.state_y]
            A = A1
        total_returns.append(tot_rw)
    return [Q,total_returns]

def q_learning(num_of_episodes):
    alpha = 0.5
    epsilon = 0.1
    gamma = 1
    Q = init_Q()
    total_returns = []
    for i in range(0, num_of_episodes):
        # print(i)
        pl = player(start_state[0],start_state[1])
        S = [pl.state_x,pl.state_y]
        tot_rw = 0
        while(pl.state_x!=goal_state[0] or pl.state_y!=goal_state[1]):
            A = get_next_action_based_on_Q(pl.state_x,pl.state_y,Q,epsilon)
            R = pl.take_action(A)
            tot_rw+=R
            A1 = get_next_action_based_on_Q(pl.state_x,pl.state_y,Q,0)
            Q[state_to_int(S)][A] = Q[state_to_int(S)][A] + alpha*(R + gamma*(Q[state_to_int([pl.state_x,pl.state_y])][A1]) - Q[state_to_int(S)][A])
            S = [pl.state_x,pl.state_y]
        total_returns.append(tot_rw)
    return [Q,total_returns]

def print_policy(policy):
    for i in range(0,len(grid_world)):
        for j in range(0,len(grid_world[i])):
            act = policy[state_to_int([i,j])][0]
            if(act == up):
                print("U",end=" ")
            elif(act == down):
                print("D",end=" ")
            elif(act == left):
                print("L",end=" ")
            elif(act == right):
                print("R",end=" ")
        print()

def print_policy_based_on_Q(Q):
    for i in range(0,len(grid_world)):
        for j in range(0,len(grid_world[i])):
            act = np.argmax(Q[state_to_int([i,j])])
            if(act == up):
                print("U",end=" ")
            elif(act == down):
                print("D",end=" ")
            elif(act == left):
                print("L",end=" ")
            elif(act == right):
                print("R",end=" ")
        print()
    
start_time = time.time()
res_mc = monte_carlo(10000)
print("MC finished in %s seconds" % (time.time()-start_time))
start_time = time.time()
res_sarsa = sarsa(10000)
print("SARSA finished in %s seconds" % (time.time()-start_time))
start_time = time.time()
res_ql = q_learning(10000)
print("Q-Learning finished in %s seconds" % (time.time()-start_time))
print("Monte Carlo Policy")
print_policy_based_on_Q(res_mc[0])
print("SARSA Policy")
print_policy_based_on_Q(res_sarsa[0])
print("Q-Learning Policy")
print_policy_based_on_Q(res_ql[0])
plt.plot(res_mc[1], label = "Monte-Carlo")
plt.plot(res_sarsa[1], label = "SARSA")
plt.plot(res_ql[1], label = "Q-Learning")
plt.xlabel('Episodes')
plt.ylabel('Average Reward')
plt.title('Average Reward vs Episodes')
plt.legend()
plt.show()
# plt.savefig('windy_grid.png')
# plt.close()
