#include "city.h"
#include <fstream>
#include <string.h>
#include <random>
#include <iostream>
void city::set_name(char n){
    name = n;
}

void city::set_num_of_customers(int n){
    num_of_customers = n;
}

void city::set_prob(double p){
    prob = p;
}

char city::get_name(){
    return name;
}

double city::get_dist_to_city(char n){
    return dist.find(n)->second;
}

double city::get_prob(){
    return prob;
}

int city::get_num_of_customers(){
    return num_of_customers;
}

// get_reward gives the number of customers willing to buy. The function also
// removes the these customers from num_of_customers in the city as they no
// longer will be willing to buy the good(as per assumption)
double city::get_buys(){
    // initialise generator and distribution for bernoulli dist
    std::default_random_engine generator;
    std::bernoulli_distribution distribution(prob);

    int num_buys = 0; // indicates the number of customers who bought the good

    // to get the number of buyers.
    for(int i=0;i<num_of_customers;i++){
        if(distribution(generator)) ++num_buys;
    }

    // The customers who buy the good once will not be willing to buy the good again(as per assumption)
    num_of_customers-=num_buys;

    return num_buys;
}

void city::set_new_neighbor(char n, double d){
    dist.insert({n,d});
}

map<char,city*> parse_adj_matrix_file(string filename){
    string line;
    ifstream infile;
    infile.open(filename);
    map<char, city*> temp;

    string delimiter = " ";

    char i = 'A'; // name of starting city. i.e A is first followed by B and so on

    // reading each row
    while(!infile.eof()){
        // initialize new city
        city* c = new city();
        c->set_name(i);

        getline(infile,line);
        auto start = 0U;
        auto end = line.find(delimiter);
        char j = 'A';
        while(end != string::npos){
            c->set_new_neighbor(j,atof(line.substr(start,end-start).c_str()));
            start = end+delimiter.length();
            end = line.find(delimiter,start);
            j++;
        }
        // last term
        c->set_new_neighbor(j,atof(line.substr(start,end-start).c_str()));
        
        temp.insert({i,c});

        i++; // for next letter
    }
    return temp;
}

void city::find_possible_rewards(){
    int n = num_of_customers;
    number_of_possible_buys =0;
    while(num_of_customers!=0){
        if(get_buys()==0){
            break;
        }
        else {
            number_of_possible_buys++;
        }
    }
    num_of_customers =n;
    possible_buys = new int[number_of_possible_buys+1];
    for(int i = 0;i<=number_of_possible_buys;i++){
        possible_buys[i] = get_buys();
    }
    number_of_possible_buys ++;
    num_of_customers =n;
}

int* city::get_all_possible_buys(){
    return possible_buys;
}

int city::get_number_of_possible_buys(){
    return number_of_possible_buys;
}