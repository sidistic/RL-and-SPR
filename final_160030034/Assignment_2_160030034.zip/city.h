#include <iterator>
#include <map>

using namespace std;

class city{
    char name; // name of the city
    map<char,double> dist; // map from city name to distance to that city from current city
    int num_of_customers; // Number of customers who are willing to buy the product in the city. Reduces as time goes.
    double prob; // probability at which each customer will buy the goods
    int* possible_buys;
    int number_of_possible_buys;

    public:

    void set_name(char n);
    void set_num_of_customers(int n);
    void set_prob(double p);
    void set_new_neighbor(char n,double dist); // adds the city to its neighbors map, dist is the distance to the city from the current city
    char get_name();
    double get_dist_to_city(char n);
    double get_buys();
    double get_prob();
    int get_num_of_customers();
    void find_possible_rewards();
    int get_number_of_possible_buys();
    int* get_all_possible_buys();
};

map<char,city*> parse_adj_matrix_file(string filename);