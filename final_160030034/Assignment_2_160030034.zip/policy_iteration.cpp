#include <iostream>
#include "city.h"
#include "state.h"
#include <iterator>

using namespace std;

void initialize_city_characteristics3(map<char, city*> c);
void initialize_city_characteristics5(map<char, city*> c);
void initialize_city_characteristics10(map<char, city*> c);

int main(){
    map<char, city*> cities = parse_adj_matrix_file("test_city_n10.txt");
    initialize_city_characteristics10(cities);

    // These values must be changed every time the file is changed
    int total_goods=1000;
    int number_of_cities=10;
    int number_of_categories=50;
    state*** states = new state**[number_of_cities];
    for(int i=0;i<number_of_cities;i++) states[i] = new state*[number_of_categories];

    // initialization
    map<state* ,double> V;
    map<state*, char> pi;
    for(int i=0;i<number_of_cities;i++){
        for(int j=0;j<number_of_categories;j++){
            state* temp = new state(j,'A'+i);
            states[i][j] = temp;
            V.insert({temp,0});
            pi.insert({temp,'A'});
        }
    }

    while(true)
    {
        // policy evaluation
        int x=0;
        double gamma = 0.8;
        double delta = 0;
        double theta =0.1;
        do{
            delta = 0;
            for(int i = 0;i<number_of_cities;i++){
                for(int j=0;j<number_of_categories;j++){
                    state* s = states[i][j];
                    double v = V.find(s)->second;
                    double V_temp = 0;
                    city* n_city = cities.find(pi.find(s)->second)->second;
                    int cost = 0;
                    if(s->get_city()!=n_city->get_name()){
                       cost = cities.find(s->get_city())->second->get_dist_to_city(n_city->get_name()) *3;
                    }
                    for(int k=0;k<n_city->get_number_of_possible_buys();k++){
                        int r = n_city->get_all_possible_buys()[k]*2;
                        // cout<<(1/double(n_city->get_number_of_possible_buys()))*(r+V.find(states[n_city->get_name()-65][get_next_category(r,s->get_category(),total_goods,number_of_categories)])->second)<<endl;
                        V_temp += (1/double(n_city->get_number_of_possible_buys()))*(r-cost+gamma*V.find(states[n_city->get_name()-65][get_next_category(r,s->get_category(),total_goods,number_of_categories)])->second);
                    }
                    delta = max(delta,abs(v-V_temp));
                    V.find(s)->second = V_temp;
                }
            }
        }while(delta >= theta);

        // policy improvement
        bool stable = true;
        for(int i = 0;i<number_of_cities;i++){
            for(int j=0;j<number_of_categories;j++){
                state* s = states[i][j];
                char old_a = pi.find(s)->second;
                double v_max= 0;
                char a_max= old_a;
                for(int p='A';p<'A'+number_of_cities;p++){
                    double v = 0;
                    city* n_city = cities.find(p)->second;
                    int cost = 0;
                    if(s->get_city()!=n_city->get_name()){
                        cost = cities.find(s->get_city())->second->get_dist_to_city(n_city->get_name())*3;
                    }
                    for(int k=0;k<n_city->get_number_of_possible_buys();k++){
                        int r = n_city->get_all_possible_buys()[k]*2;
                        v += (1/double(n_city->get_number_of_possible_buys()))*(r-cost+gamma*V.find(states[n_city->get_name()-65][get_next_category(r,s->get_category(),total_goods,number_of_categories)])->second);
                    }
                    if(v>v_max){
                        v_max=v;
                        a_max=p;
                    }
                }
                pi.find(s)->second = a_max;
                if(old_a!=a_max)stable=false;
            }
        }
        if(stable) break;
    }
    map<state*,char>::iterator itr1;
    map<state*,double>::iterator itr2;
    cout<<"city\tcat\taction\tvalue"<<endl;
    for(itr1 = pi.begin(),itr2 = V.begin();itr2!= V.end(),itr1!= pi.end();++itr1,++itr2){
        cout<<itr1->first->get_city()<<"\t"<<itr1->first->get_category()<<"\t"<<itr1->second<<"\t"<<itr2->second<<endl;
    }
}
void initialize_city_characteristics3(map<char, city*> c){
    c.find('A')->second->set_num_of_customers(50);
    c.find('A')->second->set_prob(0.8);
    c.find('A')->second->find_possible_rewards();

    c.find('B')->second->set_num_of_customers(200);
    c.find('B')->second->set_prob(0.3);
    c.find('B')->second->find_possible_rewards();

    c.find('C')->second->set_num_of_customers(100);
    c.find('C')->second->set_prob(0.6);
    c.find('C')->second->find_possible_rewards();
}
void initialize_city_characteristics5(map<char, city*> c){
    c.find('A')->second->set_num_of_customers(50);
    c.find('A')->second->set_prob(0.8);
    c.find('A')->second->find_possible_rewards();

    c.find('B')->second->set_num_of_customers(200);
    c.find('B')->second->set_prob(0.3);
    c.find('B')->second->find_possible_rewards();

    c.find('C')->second->set_num_of_customers(100);
    c.find('C')->second->set_prob(0.6);
    c.find('C')->second->find_possible_rewards();

    c.find('D')->second->set_num_of_customers(80);
    c.find('D')->second->set_prob(0.1);
    c.find('D')->second->find_possible_rewards();

    c.find('E')->second->set_num_of_customers(300);
    c.find('E')->second->set_prob(0.4);
    c.find('E')->second->find_possible_rewards();

}
void initialize_city_characteristics10(map<char, city*> c){
    c.find('A')->second->set_num_of_customers(50);
    c.find('A')->second->set_prob(0.8);
    c.find('A')->second->find_possible_rewards();

    c.find('B')->second->set_num_of_customers(200);
    c.find('B')->second->set_prob(0.3);
    c.find('B')->second->find_possible_rewards();

    c.find('C')->second->set_num_of_customers(100);
    c.find('C')->second->set_prob(0.6);
    c.find('C')->second->find_possible_rewards();

    c.find('D')->second->set_num_of_customers(80);
    c.find('D')->second->set_prob(0.1);
    c.find('D')->second->find_possible_rewards();

    c.find('E')->second->set_num_of_customers(300);
    c.find('E')->second->set_prob(0.4);
    c.find('E')->second->find_possible_rewards();

    c.find('F')->second->set_num_of_customers(120);
    c.find('F')->second->set_prob(0.9);
    c.find('F')->second->find_possible_rewards();

    c.find('G')->second->set_num_of_customers(20);
    c.find('G')->second->set_prob(1);
    c.find('G')->second->find_possible_rewards();

    c.find('H')->second->set_num_of_customers(500);
    c.find('H')->second->set_prob(0.35);
    c.find('H')->second->find_possible_rewards();

    c.find('I')->second->set_num_of_customers(250);
    c.find('I')->second->set_prob(0.5);
    c.find('I')->second->find_possible_rewards();

    c.find('J')->second->set_num_of_customers(400);
    c.find('J')->second->set_prob(0.45);
    c.find('J')->second->find_possible_rewards();

}