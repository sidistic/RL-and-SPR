echo policy
g++ policy_iteration.cpp city.cpp state.cpp -o policy
./policy

echo value
g++ value_iteration.cpp city.cpp state.cpp -o value
./value
