#include "state.h"

void state::set_category(int i){
    category_of_amt_of_goods = i;
}

void state::set_city(char c){
    city =c;
}

char state::get_city(){
    return city;
}

int state::get_category(){
    return category_of_amt_of_goods;
}

state::state(int amt, char c){
    category_of_amt_of_goods = amt;
    city =c;
}

state::state(){
    city= 'A';
    category_of_amt_of_goods = 0;
}

int get_next_category(int buys,int cat,int tot_goods, int tot_cat){
    double d = double(tot_goods)/tot_cat;
    return int(cat+0.5-buys/d);
}