class state{
    int category_of_amt_of_goods;
    char city;

    public:
    state();
    state(int amt,char c);
    void set_category(int i);
    void set_city(char c);

    char get_city();
    int get_category();
};

int get_next_category(int buys,int cat, int tot_goods, int tot_cat);