import numpy as np
import matplotlib.pyplot as plt
#matplotlib inline

class grad_bandit:

    def __init__(self, k, alpha, iters, mu='random'):
        # Number of arms
        self.k = k
        self.perc = np.zeros(iters)
        self.actions = np.arange(k)
        # Number of iterations
        self.iters = iters
        # Step count
        self.n = 1
        # Step count for each arm
        self.k_n = np.ones(k)
        # Total mean reward
        self.mean_reward = 0
        self.reward = np.zeros(iters)
        # Mean reward for each arm
        self.k_reward = np.zeros(k)
        # Initialize preferences
        self.H = np.zeros(k)
        # Learning rate
        self.alpha = alpha
        if type(mu) == list or type(mu).__module__ == np.__name__:
            # User-defined averages
            self.mu = np.array(mu)
        elif mu == 'random':
            self.mu = np.random.rand(k)
        self.regret = np.zeros(iters)


    def softmax(self):
        self.prob_action = np.exp(self.H) \
            / np.sum(np.exp(self.H), axis=0)

    def pull(self):
        # Update probabilities
        self.softmax()
        # Select highest preference action
        a = np.random.choice(self.actions, p=self.prob_action)

        #reward = np.random.normal(self.mu[a], 1)
        reward = np.random.binomial(1,self.mu[a])

        # Update counts
        self.n += 1
        self.k_n[a] += 1

        # Update total
        self.mean_reward = self.mean_reward + (
            reward - self.mean_reward) / self.n

        # Update results for a_k
        self.k_reward[a] = self.k_reward[a] + (
            reward - self.k_reward[a]) / self.k_n[a]



        # Update preferences with baseline
        # self.H[a] = self.H[a] + \
        #     self.alpha * (reward - self.mean_reward) * (1 - self.prob_action[a])
        # actions_not_taken = self.actions!=a
        # self.H[actions_not_taken] = self.H[actions_not_taken] - \
        #     self.alpha * (reward - self.mean_reward) * self.prob_action[actions_not_taken]

        # Update preferences without baseline
        self.H[a] = self.H[a] + \
            self.alpha * (reward ) * (1 - self.prob_action[a])
        actions_not_taken = self.actions!=a
        self.H[actions_not_taken] = self.H[actions_not_taken] - \
            self.alpha * (reward) * self.prob_action[actions_not_taken]
        #armpicked
        return a

    def run(self):
        for i in range(self.iters):
            arm = self.pull()
            if i == 0:
                if max(self.mu) == self.mu[arm]:
                    self.perc[i] = 1
                else:
                    self.perc[i] = 0
            else:
                if max(self.mu) == self.mu[arm]:
                    self.perc[i] = (self.perc[i-1] + 1)
                else:
                    self.perc[i] = self.perc[i-1]
            self.reward[i] = self.mean_reward
            self.regret[i] = max(self.mu) - self.mu[arm]
        for i in range(1,self.iters):
            self.perc[i] = self.perc[i]/(i+1)
    def reset(self, mu=None):
        # Resets results while keeping settings
        self.n = 0
        self.perc = np.zeros(iters)
        self.k_n = np.zeros(self.k)
        self.mean_reward = 0
        self.reward = np.zeros(iters)
        self.k_reward = np.zeros(self.k)
        self.H = np.zeros(self.k)
        self.regret = np.zeros(iters)
        if mu == 'random':
            self.mu = np.random.rand(self.k)

k = 10
iters = 1000
# Initialize bandits
grad = grad_bandit(k, 0.1, iters, mu = [0.2, 0.1, 0.5, 0.040, 0.05, 0.24, 0.1, 0.30, 0.20, 0.05])
grad1 = grad_bandit(k, 0.2, iters, mu=grad.mu)
grad2 = grad_bandit(k, 0.5, iters, mu=grad.mu)
grad1.mu = grad.mu
grad2.mu = grad.mu
print(grad.mu)




grad_regrets =  np.zeros(iters)
grad1_regrets =  np.zeros(iters)
grad2_regrets =  np.zeros(iters)

grad_perc = np.zeros(iters)
grad1_perc = np.zeros(iters)
grad2_perc = np.zeros(iters)

grad_rewards = np.zeros(iters)
grad1_rewards = np.zeros(iters)
grad2_rewards = np.zeros(iters)

opt_grad = 0
opt_grad1 = 0
opt_grad2 = 0



episodes = 20
# Run experiments
for i in range(episodes):
    # Reset counts and rewards
    grad.reset()

    grad1.reset()
    grad2.reset()

    grad1.mu = grad.mu
    grad2.mu = grad.mu

    # Run experiments
    grad.run()
    grad1.run()
    grad2.run()

    # Update long-term averages
    grad_rewards = grad_rewards + (
        grad.reward - grad_rewards) / (i + 1)
    grad1_rewards = grad1_rewards + (
        grad1.reward - grad1_rewards) / (i + 1)
    grad2_rewards = grad2_rewards + (
        grad2.reward - grad2_rewards) / (i + 1)


    # Count optimal actions
    opt_grad += grad.k_n [np.argmax(grad.mu)]
    opt_grad1 += grad1.k_n [np.argmax(grad.mu)]
    opt_grad2 += grad2.k_n [np.argmax(grad.mu)]


    grad_perc+= grad.perc
    grad1_perc+= grad1.perc
    grad2_perc+=grad2.perc

    print("Episode:",i,opt_grad,opt_grad1,opt_grad2)

    grad_regrets+=grad.regret
    grad1_regrets+=grad1.regret
    grad2_regrets+=grad2.regret


print("important",list(grad.H))
plt.figure(figsize=(12,8))
plt.plot(grad_rewards, label="2 ARM Gradient with alpha = 0.1")
plt.plot(grad1_rewards, label="2 ARM Gradient with alpha = 0.2")
plt.plot(grad2_rewards, label="2 ARM Gradient with alpha = 0.5")

#plt.plot(ucb_rewards, label="UCB")
plt.legend(bbox_to_anchor=(1.0, 0.5))
plt.xlabel("Iterations")
plt.ylabel("Average Reward")
plt.title("Average Gradient Bandit without baseline Rewards after "
          + str(episodes) + " Episodes")
plt.show()

plt.figure(figsize=(12,8))
plt.plot(grad_perc[1:]/ float(episodes) * 100.0, label="2 ARM Gradient with alpha = 0.1")
plt.plot(grad1_perc[1:]/ float(episodes) * 100.0, label="2 ARM Gradient with alpha = 0.2")
plt.plot(grad2_perc[1:]/ float(episodes) * 100.0, label="2 ARM Gradient with alpha = 0.5")

#plt.plot(ucb_rewards, label="UCB")
plt.legend(bbox_to_anchor=(1.0, 0.5))
plt.xlabel("Iterations")
plt.ylabel("Percentage of Optimal pulls")
plt.title("Percentage of optimal picks without baseline after "
          + str(episodes) + " Episodes")
plt.show()


plt.figure(figsize=(12,8))
plt.plot(grad_regrets, label="2 ARM Gradient with alpha = 0.1")
plt.plot(grad1_regrets, label="2 ARM Gradient with alpha = 0.2")
plt.plot(grad2_regrets, label="2 ARM Gradient with alpha = 0.5")

#plt.plot(ucb_regrets, label="UCB")
plt.legend(bbox_to_anchor=(1.0, 0.5))
plt.xlabel("Iterations")
plt.ylabel("Average Regret")
plt.title("Average Gradient Bandit Regrets without baseline after "
          + str(episodes) + " Episodes")
plt.show()
#import pandas as pd
bins = np.linspace(1, k,k)
print(bins,bins+0.33,bins+0.67)

fig,ax = plt.subplots(figsize=(12,8))
plt.bar(bins, grad.k_n,
        width=0.25, color='b',
        label="2 ARM Gradient Bandit with alpha = 0.1")
plt.bar(bins+0.25, grad1.k_n,
        width=0.25, color='g',
        label="2 ARM Gradient Bandit with alpha = 0.2")
plt.bar(bins+0.5, grad2.k_n,
        width=0.25, color='r',
        label="2 ARM Gradient Bandit with alpha = 0.5")
ax.set_xticks([p + 1.5 * 0.25 for p in bins])
ax.set_xticklabels(bins)
plt.xlim(min(bins)-0.5, max(bins)+1)
#plt.bar(bins+0.5, grad1.k_n,width=0.5, color='g', label="2 ARM Gradient Bandit with alpha = 0.2")
plt.legend(bbox_to_anchor=(0.75, 0.5))
plt.xlim([1,k+1])
plt.title("Actions Selected by Each Algorithm without baseline")
plt.xlabel("Action")
plt.ylabel("Number of Actions Taken")
plt.show()


print("Percentage of actions selected:",df)
print("Percentage of Optimal Selections for all episodes \nGradient: %.2f\nGradient1: %.2f\nGradient2: %.2f"
      %(
        (opt_grad / (episodes * iters) * 100),(opt_grad1 / (episodes * iters) * 100),(opt_grad2 / (episodes * iters) * 100)))
