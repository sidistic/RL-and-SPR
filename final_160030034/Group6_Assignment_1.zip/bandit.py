from scipy.stats import bernoulli
from scipy.stats import norm
import numpy
import math
import matplotlib.pyplot as py

arm_par_2_bern=[0.79,0.18]
arm_par_5_bern=[0.18, 0.69, 0.42, 0.31, 0.97]
arm_par_10_bern=[0.2, 0.1, 0.5, 0.040, 0.05, 0.24, 0.1, 0.30, 0.20, 0.05]

# optimal_arm_bern finds the optimal arm, given the set of arm paramaters
# here it is the arm with the maximum probabilities
def optimal_arm_bern(arm_par):
    max = 0
    for i in range(0,len(arm_par)):
        if arm_par[i] > arm_par[max]:
            max = i
    return max

# ret_reward 
def ret_reward(list,index,type):
    val = -1
    if type == 1:
        val = bernoulli.rvs(list[index],loc=0,size=1)
    else:
        val = norm.rvs(loc=list[index,0],scale=(list[index,1]),size=1,random_state = None)
    return val[0]
    

def pick_arm(pick_prob):
    index=numpy.random.choice(numpy.arange(1, len(pick_prob)+1), p=pick_prob)
    return index

def update_mu(list,index,reward,round):
    list[index] = float(list[index]) + (1/(float(round)+1))*(reward - list[index])

def UCB(list,round,freq_list):
    max = 0
    max_i=0
    for i in range(0,len(list)):
        qt = list[i] + math.sqrt(2*math.log(round)/freq_list[i])
        if qt > max:
            max_i= i
            max = qt
    return max_i
    
def init_UCB_val(arm_par):
    act_list = []
    for i in range(0,len(arm_par)):
        act_list.append(ret_reward(arm_par,i,1))
    return act_list

def add_list(l1,l2):
    for i in range(0,len(l1)):
        l1[i]+=l2[i]

def experiment(t_round,arm_par):
    action_vals = init_UCB_val(arm_par)
    N = len(arm_par)
    freq=[]
    cum_regret = []
    reg_per_turn = []
    percentage_opt_play = []
    opt_arm = optimal_arm_bern(arm_par)
    cumu=0
    for i in range(0,len(arm_par)):
        freq.append(1)
        cum_regret.append(cumu+arm_par[opt_arm]-arm_par[i])
        reg_per_turn.append(arm_par[opt_arm]-arm_par[i])
        cumu = cum_regret[len(cum_regret)-1]
        if i < opt_arm:
            percentage_opt_play.append(0)
        else:
            percentage_opt_play.append(freq[opt_arm]/sum(freq))

    for i in range(N,t_round):
        arm = UCB(action_vals,i,freq)
        freq[arm]+=1
        reward = ret_reward(arm_par,arm,1)
        cum_regret.append(cum_regret[len(cum_regret)-1]+arm_par[opt_arm]-arm_par[arm])
        reg_per_turn.append(arm_par[opt_arm]-arm_par[arm])
        update_mu(action_vals,arm,reward,i)
        percentage_opt_play.append(freq[opt_arm]/float(sum(freq)))

    return [action_vals,freq,cum_regret,percentage_opt_play,reg_per_turn]

def full_exp(arm_par):
    mu=[]
    freq =[]
    cum_reg=[]
    perc_opt=[]
    reg_per_t=[]
    num_experiments = 250
    for i in range(0,num_experiments):
        temp = experiment(1000,arm_par)
        if i ==0:
            mu = temp[0]
            freq= temp[1]
            cum_reg= temp[2]
            perc_opt=temp[3]
            reg_per_t=temp[4]
        else:
            add_list(mu,temp[0])
            add_list(freq, temp[1])
            add_list(cum_reg, temp[2])
            add_list(perc_opt,temp[3])
            add_list(reg_per_t,temp[4])
    for i in range(0,len(mu)):
        mu[i]=mu[i]/num_experiments
    for i in range(0,len(freq)):
        freq[i]=freq[i]/num_experiments
    for i in range(0,len(cum_reg)):
        cum_reg[i]=cum_reg[i]/num_experiments
    for i in range(0,len(perc_opt)):
        perc_opt[i]=perc_opt[i]/num_experiments
    for i in range(0,len(reg_per_t)):
        reg_per_t[i]=reg_per_t[i]/num_experiments
    print("mu:",mu)
    print("freq:",freq)
    return [cum_reg,perc_opt,reg_per_t]


k2=full_exp(arm_par_2_bern)
k5=full_exp(arm_par_5_bern)
k10=full_exp(arm_par_10_bern)

py.plot(k2[0],label="K=2")
py.plot(k5[0],label="K=5")
py.plot(k10[0],label="K=10")
py.xlabel("turns")
py.ylabel("cumulative regret")
py.title("values are averaged over 250 experiments")
py.legend()
py.show()
py.plot(k2[1],label="K=2")
py.plot(k5[1],label="K=5")
py.plot(k10[1],label="K=10")
py.xlabel("turns")
py.ylabel("percentage optimal arm picks")
py.title("values are averaged over 250 experiments")
py.legend()
py.show()
py.plot(k2[2],label="K=2")
py.plot(k5[2],label="K=5")
py.plot(k10[2],label="K=10")
py.xlabel("turns")
py.ylabel("regret per turn")
py.title("values are averaged over 250 experiments")
py.legend()
py.show()




