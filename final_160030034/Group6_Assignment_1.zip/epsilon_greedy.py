import numpy as np
import random
import matplotlib.pyplot as plt

#Common for all bandit algorithm
class Entities:
    def __init__(self,n_arms=None,n_trials=None,e=0.05):
        self.e = e
        self.n_arms = n_arms
        self.n_trials = n_trials
        #Total No. Rewards for each arm
        self.R = np.ones(self.n_arms)
        #No. of times that particular arm is chosen
        self.N = np.ones(self.n_arms)
        self.mu = np.zeros(self.n_arms)
        #Rewards for each trail
        self.reward = 0
        #Total Rewards
        self.total_rewards = 0
        #Picked arm in each trial
        self.k = 0
        #Trail number
        self.i = 0

        #Regrets
        self.regrets = np.zeros(self.n_trials)
        #Stores which arm is at each pick
        self.arm_i = np.zeros(self.n_trials)
        #Reward for each pick
        self.r_i = np.zeros(self.n_trials)
        #mu of the chosen arm in ith draw
        # self.MU = np.zeros(self.n_trials)
        #Random values generated to compare with given epsilon value for each trial
        self.ep = np.random.uniform(0,1,size=self.n_trials)
    
    def data(self):
        print(self.total_rewards)

#Greedy algorithm
class eGreedy(Entities):

    def __init__(self,n_arms,n_trials,e,arms):
        super().__init__(n_arms,n_trials,e)
        self.arms = arms
        

    def choose_k(self):

        #If the probability is less than e choose random draw or else maximum mu
        self.k = np.random.choice(self.arms) if(self.ep[self.i] < self.e) else np.argmax(self.mu)
        return self.k
    
    def update(self):

        self.N[self.k] += 1
        self.R[self.k] += self.reward
        self.mu[self.k] = self.R[self.k]/self.N[self.k]

        # self.MU[self.i] = self.mu[self.k]
        #Regret calculation
        self.regrets[self.i] = payouts[optimal_arm] - self.mu[self.k]
        # print(self.regrets[self.i])

        self.arm_i[self.i] = self.k
        self.r_i[self.i] = self.reward
        self.i += 1

#To run any type of  Bandit Algorithms
def run(type,n_trials,average_regrets):

    for i in range(n_trials):
        arm_k = type.choose_k()
        #Assign reward
        reward = np.random.binomial(1, p=payouts[arm_k])
        type.reward = reward
        #Update the quantities
        type.update()
        type.total_rewards += reward
        #Getting no. of times optimal arm is pulled
        avg_optimal_arms_played[i] += np.count_nonzero(type.arm_i[0:i+1] == optimal_arm)/(i+1)
        if(np.count_nonzero(type.arm_i[0:i+1] == optimal_arm)> (i+1)):
            print("Error")
    average_regrets += type.regrets
    return type.total_rewards,type.mu

##################################################################################

n_trials = 1000
n_experiments = 100
#Set of number of arms
K = [2,5,10]
#Epsilon value
ep = 0.1
initial_values=[[0.79, 0.18],[0.18, 0.69, 0.42, 0.31, 0.97],[0.2, 0.1, 0.5, 0.040, 0.05, 0.24, 0.1, 0.30, 0.20, 0.05]]
#Initial probability distribution values
payouts = []
#Optimal arm chosen, needs to be global
optimal_arm = np.array([])

#Initialising the averages, needs to be global
average_regrets=np.zeros(n_trials)
avg_optimal_arms_played = np.zeros(n_trials)
average_rewards = 0

#Plots properties and naming
fig, (ax1, ax2) = plt.subplots(2,1)
plt.subplots_adjust(hspace=.5)

fig1 = plt.figure()
ax3 = plt.axes()
ax1.set_title('Regret per turn, epsilon - ' + str(ep))
ax1.set_xlabel('Trials')

ax2.set_title('Cumulative Regret, epsilon - ' + str(ep))
ax2.set_xlabel('Trials')

ax3.set_xlabel('Trials')
ax3.set_title('Percentage of optimal arm picked, epsilon - ' + str(ep))



#############################################################################################
#                                         Epsilon-greedy 
#############################################################################################
for j,k in enumerate(K):

    payouts = initial_values[j]
    print(payouts)
    optimal_arm = np.argmax(payouts)
    print("Optimal Arm ",optimal_arm)
    #Action value
    average_mu = np.zeros(k)
    for i in range(n_experiments):
        arms = np.arange(k)
        greed = Entities(n_arms=int(k),n_trials = n_trials)
        Greedy = eGreedy(n_arms=int(k),n_trials = n_trials,e=ep,arms=arms)
        temp,temp1= run(Greedy,n_trials,average_regrets)
        average_rewards += temp
        average_mu += temp1

    #Calculating Average
    avg_optimal_arms_played = avg_optimal_arms_played/n_experiments
    average_regrets = average_regrets/n_experiments
    average_mu = average_mu/n_experiments
    Cumulative_regrets = np.zeros(n_trials)
    #Cumulative Regret
    for i in range(n_trials):
        Cumulative_regrets[i] = np.sum(average_regrets[0:i+1])

    #Plot for average regrets
    ax1.plot(average_regrets,label="K="+str(k))
    #Plot of cumulative regrets
    ax2.plot(Cumulative_regrets,label="K="+str(k))
    #Plots for percentage of optimal arm picked
    ax3.plot(avg_optimal_arms_played,label="K="+str(k))
    #Total average reward
    average_rewards = average_rewards/n_trials
    #Total average action value
    average_mu = average_mu/n_trials
    print("average_mu",average_mu)
    print("total reward",average_rewards)
    print("average_optimal_arm picked",avg_optimal_arms_played[n_trials-1])
    print("---------------------------------------------------")
    #Initialising the averages
    average_regrets=np.zeros(n_trials)
    avg_optimal_arms_played = np.zeros(n_trials)
    average_rewards = 0

ax1.legend(loc=1)
ax2.legend(loc=1)
ax3.legend(loc=1)
plt.show()

