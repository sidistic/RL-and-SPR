import numpy as np
import sys
import math

# GLOBAL ACROSS EXPERIMENTS --------
numberOfTrials = 1000
numberOfExperiments = 250
regretsGlobal = np.zeros(numberOfTrials)
numberOfPicksGlobal = np.zeros(numberOfExperiments)
# temperature variable controls the way the arms are picked... at temp = 0, greedy, temp ~ inf, random
temperature = 0.1
numberOfArms = 10
# Don't change this across the experiments
initialMeans = np.array([0.2, 0.1, 0.5, 0.040, 0.05, 0.24, 0.1, 0.30, 0.20, 0.05])

# FUNCTIONS FOR SOFTMAX

def findArm(probabilityArray):
    changedArray = np.zeros(numberOfArms)
    for i in range(0, numberOfArms):
        temp = 0
        for j in range(0, i+1):
            temp += probabilityArray[j]
        changedArray[i] = temp
    rand = np.random.random_sample()
    # print "random number - ", rand
    for i in range(0, numberOfArms):
        if rand <= changedArray[i]:
            # print "Chosen Arm - ", i
            break
    return i

def chooseArm (muUpdated):
    changedArray = np.zeros(numberOfArms)
    for i in range(0, numberOfArms):
        changedArray[i] = muUpdated[i] / temperature
    exponentArray = np.exp(changedArray)
    # print "exponent array - ", exponentArray
    denom = np.sum(exponentArray)
    probabilityArray = np.zeros(numberOfArms)
    for x in range(0, numberOfArms):
        probabilityArray[x] = exponentArray[x] / denom
    return findArm(probabilityArray)

def updateRewards(iterationNumber, chosenArm):
    # main program will update the running arm
    # get the reward for this arm, update the rewards array, add the one to the array of selections
    temp = np.random.random_sample()
    reward = -1
    if temp <= initialMeans[chosenArm]:
        reward = 1
    else:
        reward = 0
    rewardEachPick[iterationNumber] = reward
    numberOfPicks[chosenArm] += 1

def updateMu (muUpdated, chosenArm, iterationNumber):
    # mu_i(t+1)  = mu_i(t) + (1/t+1) (R_(t+1) - mu_i(t)) 
    temp = muUpdated[chosenArm] + (1/(numberOfPicks[chosenArm]+1)) * ( rewardEachPick[iterationNumber] - muUpdated[chosenArm] )
    muUpdated[chosenArm] = temp
    return temp

def calculateRegret(muUpdated, chosenArm, iterationNumber):
    maxMean = np.max(muUpdated)
    # print "max mean, muupdated - ", maxMean, muUpdated[chosenArm]
    regret = maxMean - muUpdated[chosenArm]
    # print "regret - ", regret
    regrets[iterationNumber] = regret

# MAIN LOOPS

# add for loop across number of experiments variable
optimalArm = np.argmax(initialMeans)
# These variables are for a set of arms, used internally within a experiment, size of lists - k


for a in range(0, numberOfExperiments):
    
    regrets = np.zeros(numberOfTrials)
    rewardEachPick = np.zeros(numberOfTrials)
    numberOfPicks = np.zeros(numberOfArms)
    muUpdated = np.zeros(numberOfArms)
    listOfArms = np.arange(numberOfArms)

    for i in range(0, numberOfTrials):
        armChosen = chooseArm(muUpdated)
        updateRewards(i, armChosen)
        updatedMuValue = updateMu(muUpdated, armChosen, i)
        calculateRegret(muUpdated, armChosen, i)
    print (a)    
    print "Regret sum - ", np.sum(regrets)
    print "number of times optimal - ", numberOfPicks[optimalArm]
    numberOfPicksGlobal[a] = numberOfPicks[optimalArm]

    for j in range(0, numberOfTrials):
        temp1 = regretsGlobal[j]*a
        temp2 = regrets[j]
        tempFinal = temp1 + temp2
        tempFinal = tempFinal/(a+1)
        regretsGlobal[j] = tempFinal

# For graphing - 
# Use regretsGlobal to get a series of averaged out regrets across all the experiments. Plot this from time 0-numberOfExperiments to get regret as a function of time... Pretty sure this will just be noise, because it seems to learn pretty fast enough
# Number of optimal arms averaged out is printed below, can use that
# total regret is printed below

print "Regret sum - ", np.sum(regretsGlobal)
print "number of times optimal - ", np.average(numberOfPicksGlobal)


