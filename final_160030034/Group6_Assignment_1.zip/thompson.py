import numpy as numpy
import matplotlib.pyplot as plt 
# pick_prob=[0,0,1,0]
# y=numpy.random.choice(numpy.arange(1, len(pick_prob)+1), p=pick_prob)
# print (y)


from scipy.stats import bernoulli
from scipy.stats import norm
from scipy.stats import beta

# arm_par_2_bern:[0.4,0.8]

# def init_pick_prob(arm_par):
#     l = len(arm_par)
#     pr = 1/l
#     pick_prob =[]
#     for i in range(0,l):
#         pick_prob

def optimal_arm_bern(arm_par):
    max = 0
    for i in range(arm_par):
        if arm_par[i] > arm_par[max]:
            max = i
    return max

def optimal_arm_normal(arm_par):
    max = 0
    for i in range(arm_par):
        if arm_par[i][0] > arm_par[max][0]:
            max = i
    return max

def ret_reward(list,index,type):
    if type == 1:
        val= bernoulli.rvs(list(index),loc=0,size=1)
    else:
        val= norm.rvs(loc=list(index,0),scale=list(index,1),size=1,random_state = None)
    return val[0]

def pick_arm(pick_prob):
    index=numpy.random.choice(numpy.arange(1, len(pick_prob)+1), p=pick_prob)
    return index

theta=[0.4, 0.2, 0.6, 0.35]
def thompson_sampling(theta):
	# len=len(theta)
	alpha=[]
	beta=[]
	arm_reward=[]
	arm_freq=[]
	mean_arm_reward=[]
	for i in range(len(theta)):
		alpha+=[1]
		beta+=[1]
		arm_reward+=[0]
		arm_freq+=[0]
		mean_arm_reward+=[0]
	regret=[]
	freq=0
	reward=[]
	fraction=[]

	optimal_arm=numpy.argmax(theta)
	for y in range(1000):#no of trials
		k=[]
		for i in range(len(theta)):
			k+=[numpy.random.beta(alpha[i],beta[i])]# random picking from beta distbn 
		j=numpy.argmax(k) #arm to be pulled
		arm_freq[j]+=1
		if j==optimal_arm:
			freq+=1
		fraction+=[freq/float(y+1)]
		trial=bernoulli.rvs(theta[j],loc=0,size=1)
		reward+=[trial]
		if trial==1:
			alpha[j]+=1
			arm_reward[j]+=1
		else:
			beta[j]+=1
		mean_arm_reward[j]=arm_reward[j]/float(arm_freq[j])
		regret.append(max(mean_arm_reward)-trial)
		# print(freq/(y+1))
	# print(mean_arm_reward,arm_freq)
	# print(regret)

	return regret,fraction,alpha,beta
	
regret_2,fraction_2,alpha_2,beta_2=thompson_sampling([0.79, 0.18])
regret_5,fraction_5,alpha_5,beta_5=thompson_sampling([0.18, 0.69, 0.42, 0.31, 0.97])
regret_10,fraction_10,alpha_10,beta_10=thompson_sampling([0.2, 0.1, 0.5, 0.040, 0.05, 0.24, 0.1, 0.30, 0.20, 0.05])

# print (A,B,regret,fraction)
x_axis=list(xrange(1000))
y2=regret_2
y5=regret_5
y10=regret_10
# print(alpha_2,alpha_5,alpha_10)
# print(beta_2,beta_5,beta_10)
plt.xlabel('No of turns')
plt.ylabel('Regret per turn')
plt.plot(x_axis,y2,label="k=2")
plt.plot(x_axis,y5,label="k=5")
plt.plot(x_axis,y10,label="k=10")
plt.legend()
plt.show()
